import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { useState } from 'react';

export default function Giaodien3() {
  const [quantity, setQuantity] = useState<number>(1);

  const increase = (): void => setQuantity((prev) => prev + 1);
  const decrease = (): void =>
    setQuantity((prev) => (prev > 1 ? prev - 1 : prev));

  return (
    <View style={{ flex: 1, backgroundColor: '#C4C4C4' }}>
      <View
        style={{ padding: 15, flexDirection: 'row', backgroundColor: 'white' }}>
        {/* Ảnh sách */}
        <Image
          source={require('../assets/book.png')}
          style={{ width: 120, height: 150, marginRight: 10 }}
          resizeMode="contain"
        />

        {/* Thông tin sách */}
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: 'bold' }}>
            Nguyên hàm tích phân và ứng dụng
          </Text>
          <Text style={{ marginTop: 5 }}>Cung cấp bởi Tiki Trading</Text>

          {/* Giá khuyến mãi */}
          <Text
            style={{
              fontWeight: 'bold',
              fontSize: 20,
              color: 'red',
              marginTop: 5,
            }}>
            141.800 đ
          </Text>

          {/* Giá gốc */}
          <Text
            style={{
              marginTop: 5,
              textDecorationLine: 'line-through',
              color: 'grey',
            }}>
            141.800 đ
          </Text>

          {/* Hàng chứa số lượng + Mua sau */}
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: 10,
            }}>
            {/* Bộ chọn số lượng */}
            <View style={styles.quantityBox}>
              <TouchableOpacity
                onPress={decrease}
                disabled={quantity === 1}
                style={[
                  styles.button,
                  quantity === 1 && styles.disabledButton,
                ]}>
                <Text style={styles.buttonText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.quantityText}>{quantity}</Text>
              <TouchableOpacity onPress={increase} style={styles.button}>
                <Text style={styles.buttonText}>+</Text>
              </TouchableOpacity>
            </View>

            {/* Nút mua sau */}
            <TouchableOpacity>
              <Text style={{ color: '#1E90FF', fontWeight: 'bold' }}>
                Mua sau
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Mã giảm giá đã lưu */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          padding: 15,
          paddingTop: 0,
          backgroundColor: 'white',
        }}>
        <Text style={{ fontWeight: 'bold', marginRight: 20 }}>
          Mã giảm giá đã lưu
        </Text>
        <TouchableOpacity>
          <Text style={{ color: '#1E90FF', fontWeight: 'bold' }}>
            Xem tại đây
          </Text>
        </TouchableOpacity>
      </View>

      {/* Ô nhập mã giảm giá + nút áp dụng */}
      <View
        style={{
          flexDirection: 'row',
          backgroundColor: 'white',
          padding: 15,
        }}>
        {/* Ô Mã giảm giá */}
        <View style={styles.codeBox}>
          <Image
            source={require('../assets/yellow_block.svg')}
            style={{ width: 20, height: 20, marginRight: 5 }}
            resizeMode="contain"
          />
          <Text style={styles.codeText}>Mã giảm giá</Text>
        </View>

        {/* Nút áp dụng */}
        <TouchableOpacity style={styles.applyButton}>
          <Text style={styles.applyText}>Áp dụng</Text>
        </TouchableOpacity>
      </View>

      {/* Phiếu quà tặng */}
      <View style={styles.giftRow}>
        <Text style={{ fontWeight: 'bold' }}>
          Bạn có phiếu quà tặng Tiki/Got it/Urbox?
        </Text>
        <TouchableOpacity>
          <Text style={styles.linkText}> Nhập tại đây?</Text>
        </TouchableOpacity>
      </View>

      {/* Tạm tính */}
      <View style={styles.priceRow}>
        <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Tạm tính</Text>
        <Text style={styles.salePrice}>141.800 đ</Text>
      </View>

      {/* Footer */}
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: 'white',
          padding: 15,
        }}>
        {/* Thành tiền */}
        <View style={styles.totalRow}>
          <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Thành tiền</Text>
          <Text style={styles.salePrice}>141.800 đ</Text>
        </View>

        {/* Nút đặt hàng */}
        <TouchableOpacity style={styles.checkoutButton}>
          <Text style={styles.checkoutText}>TIẾN HÀNH ĐẶT HÀNG</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  quantityBox: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    overflow: 'hidden',
  },
  button: {
    paddingHorizontal: 12,
    backgroundColor: '#eee',
  },
  disabledButton: {
    backgroundColor: '#ddd',
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  quantityText: {
    paddingHorizontal: 20,
    fontSize: 18,
  },
  codeBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 10,
    height: 40,
    backgroundColor: '#fff',
  },
  codeText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  applyButton: {
    backgroundColor: '#0A5EB7',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginLeft: 8,
  },
  applyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  giftRow: {
    marginTop: 15,
    flexDirection: 'row',
    backgroundColor: 'white',
    padding: 15,
  },
  priceRow: {
    marginTop: 15,
    padding: 15,
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  totalRow: {
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  checkoutButton: {
    backgroundColor: 'red',
    borderRadius: 4,
    alignItems: 'center',
    paddingVertical: 12,
    marginTop: 20,
  },
  checkoutText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  salePrice: {
    fontWeight: 'bold',
    fontSize: 20,
    color: 'red',
    marginTop: 5,
  },
  linkText: {
    color: '#1E90FF',
    fontWeight: 'bold',
  },
});
