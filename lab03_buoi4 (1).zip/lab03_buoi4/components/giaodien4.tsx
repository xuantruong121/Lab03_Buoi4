import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Switch,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  Platform,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";

export default function App() {
  const [length, setLength] = useState<string>("");
  const [includeLower, setIncludeLower] = useState(true);
  const [includeUpper, setIncludeUpper] = useState(false);
  const [includeNumber, setIncludeNumber] = useState(true);
  const [includeSymbol, setIncludeSymbol] = useState(false);
  const [password, setPassword] = useState("");

  const generatePassword = () => {
    let chars = "";
    if (includeLower) chars += "abcdefghijklmnopqrstuvwxyz";
    if (includeUpper) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (includeNumber) chars += "0123456789";
    if (includeSymbol) chars += "!@#$%^&*()_-+=<>?/{}[]|";

    if (chars === "" || Number(length) <= 0) {
      setPassword("Invalid settings");
      return;
    }

    let pass = "";
    for (let i = 0; i < Number(length); i++) {
      const randomIndex = Math.floor(Math.random() * chars.length);
      pass += chars[randomIndex];
    }
    setPassword(pass);
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.safeArea}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
            <View style={styles.container}>
              <View style={styles.card}>
                <Text style={styles.title}>PASSWORD GENERATOR</Text>

                <View style={styles.passwordBox}>
                  <Text style={styles.passwordText}>{password}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Password length</Text>
                  <TextInput
                    style={styles.input}
                    keyboardType="numeric"
                    value={length}
                    onChangeText={setLength}
                  />
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Include lower case letters</Text>
                  <Switch value={includeLower} onValueChange={setIncludeLower} />
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Include upcase letters</Text>
                  <Switch value={includeUpper} onValueChange={setIncludeUpper} />
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Include number</Text>
                  <Switch value={includeNumber} onValueChange={setIncludeNumber} />
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Include special symbol</Text>
                  <Switch value={includeSymbol} onValueChange={setIncludeSymbol} />
                </View>

                <TouchableOpacity style={styles.button} onPress={generatePassword}>
                  <Text style={styles.buttonText}>GENERATE PASSWORD</Text>
                </TouchableOpacity>
              </View>
            </View>
          </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#6a6da9",
  },
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    backgroundColor: "#27235c",
    padding: 20,
    borderRadius: 10,
    width: "85%",
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  title: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  passwordBox: {
    backgroundColor: "#141136",
    padding: 10,
    marginBottom: 20,
    alignItems: "center",
    borderRadius: 5,
  },
  passwordText: {
    color: "white",
    fontSize: 16,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 5,
  },
  label: {
    color: "white",
    fontSize: 14,
    flexShrink: 1,
  },
  input: {
    backgroundColor: "white",
    width: 60,
    height: 30,
    borderRadius: 5,
    paddingHorizontal: 5,
    textAlign: "center",
  },
  button: {
    backgroundColor: "#4640c0",
    padding: 12,
    borderRadius: 8,
    marginTop: 20,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
});
