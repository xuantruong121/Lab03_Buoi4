import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  Image,
} from 'react-native';

export default function Giaodien2() {
  return (
    <View style={styles.container}>
      <View style={styles.row1}>
        <Image source={require('../assets/usb.png')}></Image>
        <Text style={styles.usbtext}>
          USB Bluetooth Music Receiver HJX-001- Biến loa thường thành loa
          bluetooth
        </Text>
      </View>

      <View style={styles.row2}>
        <Text style={styles.row2text}>Cực kỳ hài lòng</Text>
        <TouchableOpacity style={styles.rating}>
          <Image source={require('../assets/Star 5.png')} style={styles.ratingstar}></Image>
          <Image source={require('../assets/Star 5.png')} style={styles.ratingstar}></Image>
          <Image source={require('../assets/Star 5.png')} style={styles.ratingstar}></Image>
          <Image source={require('../assets/Star 5.png')} style={styles.ratingstar}></Image>
          <Image source={require('../assets/Star 5.png')} style={styles.ratingstar}></Image>
        </TouchableOpacity>
      </View>

      <View style={styles.row4}>
        <TouchableOpacity style={styles.buttonAddImg}>
          <Image source={require('../assets/camera.png')}></Image>
          <Text style={styles.textAddImg}>Thêm hình ảnh</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.row5}>
        <TextInput
          style={{
            borderWidth: 1,
            borderColor: 'grey',
            borderRadius: 10,
            height: 200,
            paddingHorizontal: 10,
            paddingTop: 10,
          }}
          placeholder="Hãy chia sẻ những điều mà bạn thích về sản phẩm"
          placeholderTextColor="grey"
          multiline={true}
          textAlignVertical="top"
        />
      </View>

      <View style={styles.row6}>
        <TouchableOpacity
          style={{
            backgroundColor: '#1511EB',
            borderRadius: 10,
            justifyContent: 'center',
            marginTop: 20,
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'white',
              fontSize: 20,
              padding: 10,
            }}>
            Gửi
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 20,
  },
  row1: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  usbtext: {
    fontWeight: 'bold',
    fontSize: 15,
  },
  row2: {
    flex: 1,
    alignItems: 'center',
  },
  row2text: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  rating: {
    flex: 1,
    flexDirection: 'row',
    marginTop: 10,
  },
  ratingstar: {
    marginHorizontal: 5,
  },
  row4: {
    flex: 1,
  },
  buttonAddImg: {
    flexDirection: 'row',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'blue',
    borderRadius: 10,
    padding: 20,
  },
  textAddImg: {
    fontWeight: 'bold',
    fontSize: 15,
    marginLeft: 10,
    marginTop: 5,
  },
  row5: {
    flex: 1,
  },
  row6: {
    flex: 1,
  },
});
